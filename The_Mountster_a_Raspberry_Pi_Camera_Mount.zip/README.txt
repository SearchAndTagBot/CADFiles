                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:216031
The Mountster: a Raspberry Pi Camera Mount by jeromemaurey is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

**The Mountster** is a *monster mount* for the Raspberry Pi Camera.  

After looking at available designs online, I decided to make my own. **A simple two piece design, fun, practical and fast to print**.  

I used the Element 14 version to position the openings.  

The camera can be screwed in place using the two holes on the side of the lens and there is an opening for the focus light.  

This is a work in progress, so please send me issues and feedback!

Make sure to also check out this useful [attachment][1] by [Ceribia][2].

[1]: https://www.thingiverse.com/thing:2776184 "Mountster Camera Attachment"
[2]: https://www.thingiverse.com/Ceribia "About Ceribia"

# Instructions

Print and use the two screw holes on the side of the lens to secure the camera in place.